package Math;

public class Point4 {
    public double punto [] = new double[4];
    public double x;
    public double y;
    public double z;
    public double w;
}
