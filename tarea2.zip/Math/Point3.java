package Math;

public class Point3 {
    public double punto [] = new double[3];
    public double x;
    public double y;
    public double w;
}
