package MathForGP;

public class EcParSegReg {
    double x1;
    double y1;
    double x2;
    double y2;
    public static double[] solve(EcParSegReg epsr1, EcParSegReg epsr2){
        double[] resultado = {0,0};
        return resultado;
    } 
}
